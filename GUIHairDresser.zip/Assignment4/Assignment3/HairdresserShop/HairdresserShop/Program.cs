﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace HairdresserShop
{
    class Program
    {
        enum Clients
        {
            Gentlemen,
            Ladies,
            Children
        }
        enum Services
        {
            Hairwash,
            Hairdye,
            Hairtrim

        }
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Go();
            Console.ReadKey();
        }

        public void Go()
        {
            //Sorted list for Appointments
            SortedList<int, string> AppointmentTable = new SortedList<int, string>() {
                {1, "9:00 AM"},
                {2, "10:00 AM"},
                {3, "11:00 AM"},
                {4, "12:00 PM"},
                {5, "1:00 PM"},
                {6, "2:00 PM"},
                {7, "3:00 PM"},
                {8, "4:00 PM"},
                {9, "5:00 PM"},
                {10, "6:00 PM"}

            };
            
            AppointmentList AppointmentList = new AppointmentList();

            bool needAppointment = false;

            
            do
            {

                string response = string.Empty;
                string answer = string.Empty;
                do
                {
                    Console.Write("Do you need an appointment?(y/n): ");
                    answer = Console.ReadLine();
                } while (answer.ToUpper() != "Y" && answer.ToUpper() != "N");

                if (answer.ToUpper() == "N")
                {
                    needAppointment = false;
                    continue;
                }

                // Select appointment slots
                int selectedSlot = 0;
                string selectedSlotInput = string.Empty;

                Console.WriteLine("Available Slots");
                foreach (KeyValuePair<int, string> slot in AppointmentTable)
                {
                    Console.WriteLine("{0}. {1}", slot.Key, slot.Value);
                }
                do
                {
                    Console.Write("Choose a slot for appointment [0 to exit]: ");
                    selectedSlotInput = Console.ReadLine();
                } while (!int.TryParse(selectedSlotInput, out selectedSlot) || (!AppointmentTable.ContainsKey(selectedSlot) && selectedSlot != 0));

                if (selectedSlot == 0)
                {
                    needAppointment = false;
                    continue;
                }
          
                else if (AppointmentTable.ContainsKey(selectedSlot))
                {
                    Appointment appointment = new Appointment();
                    appointment.Time = AppointmentTable[selectedSlot];

                    Console.WriteLine("\nWe offer common services for all ages and genders:");
                    var services = Enum.GetValues(typeof(Services));

                    foreach (var service in services)
                    {
                        Console.WriteLine("* {0}", service);
                    }

                    Console.WriteLine("\nAdditional offers for clients:");
                    var categoryclient = Enum.GetNames(typeof(Clients));
                    int i = 0;
                    foreach (var clients in categoryclient)
                    {

                        Console.WriteLine("{0}. {1}", ++i, clients);
                    }
                    string clientChoice = string.Empty;
                    int ch = 0;
                    do
                    {
                        Console.Write("Please enter your category(1-3) [press 0 to exit from here]: ");
                        clientChoice = Console.ReadLine();
                    } while (!int.TryParse(clientChoice, out ch) || (ch < 0 || ch > categoryclient.Length));

                    if (ch > 0)
                    {


                        string clientAgeString = string.Empty;
                        int clientAge = 0;
                        int minAge = 0, maxAge = 0;
                        if ((ch - 1) == (int)Clients.Gentlemen || (ch - 1) == (int)Clients.Ladies)
                        {
                            minAge = 17;
                            maxAge = 70;
                            do
                            {
                                Console.Write("Client Age (17-70 yrs): ");
                                clientAgeString = Console.ReadLine();
                            } while (!int.TryParse(clientAgeString, out clientAge) || (clientAge < minAge || clientAge > maxAge));
                        }
                        else
                        {
                            minAge = 4;
                            maxAge = 16;
                            do
                            {
                                Console.Write("Client Age (4-16 yrs): ");
                                clientAgeString = Console.ReadLine();
                            } while (!int.TryParse(clientAgeString, out clientAge) || (clientAge < minAge || clientAge > maxAge));

                        }


                        string clientHeightString = string.Empty;
                        decimal clientHeight = 0m;
                        do
                        {
                            Console.Write("Client Height ( 40-300 cms): ");
                            clientHeightString = Console.ReadLine();
                        } while (!decimal.TryParse(clientHeightString, out clientHeight) || (clientHeight < 40 || clientHeight > 300));

                        string clientCard = string.Empty;

                        do
                        {
                            Console.Write("Please Enter the credit card number (16 digit): ");
                            clientCard = Console.ReadLine();
                        } while (!(clientCard.All(char.IsDigit)) || !((clientCard.Length) == 16));

                        Client customer = null;

                        switch (ch - 1)
                        {
                            case (int)Clients.Gentlemen:
                                do
                                {
                                    Console.Write("Do you want trim beard and moustaches service?(y/n) ");
                                    response = Console.ReadLine();
                                } while ((response != "y") && (response != "n"));
                                Gentlemen gentle = new Gentlemen();
                                gentle.Operation();
                                customer = new Gentlemen(clientAge, clientHeight, clientCard, (response == "y") ? true : false);
                                break;
                            case (int)Clients.Ladies:
                                do
                                {
                                    Console.Write("Do you want hair styling service?(y/n) ");
                                    response = Console.ReadLine();
                                } while ((response != "y") && (response != "n"));
                                Ladies lady = new Ladies();
                                lady.Operation();
                                customer = new Ladies(clientAge, clientHeight, clientCard, (response == "y") ? true : false);
                                break;
                            case (int)Clients.Children:
                                string childResponse1 = string.Empty;
                                string childResponse2 = string.Empty;
                                do
                                {
                                    Console.Write("Do you want sensitive trimmer service?(y/n) ");
                                    childResponse1 = Console.ReadLine();
                                } while ((childResponse1 != "y") && (childResponse1 != "n"));
                                do
                                {
                                    Console.Write("Do you want adjustable seat?(y/n) ");
                                    childResponse2 = Console.ReadLine();
                                } while ((childResponse2 != "y") && (childResponse2 != "n"));
                                Children child = new Children();
                                child.Operation();
                                customer = new Children(clientAge, clientHeight, clientCard, (childResponse1 == "y") ? true : false, (childResponse2 == "y") ? true : false);
                                break;

                            default:
                                throw new Exception("You shouldn't be here");

                        }
                        appointment.Customer = customer;
                        AppointmentList.Add(appointment);
                        AppointmentList.Sort();//Sorting according to age

                        // remove selected slot from slot table
                        if (AppointmentTable.ContainsKey(selectedSlot))
                        {
                            AppointmentTable.Remove(selectedSlot);
                        }

                    }

                }
                needAppointment = true;
            } while (needAppointment && AppointmentTable.Count > 0);

            
            Console.WriteLine("\n!!!  Appointment Schedule  !!!\n");
            for (int i = 0; i < AppointmentList.Count; i++)
            {
                if (AppointmentList[i].Customer != null)
                {
                    Console.WriteLine(" Appointment Time: {0}\n Customer Type: {1}\n", AppointmentList[i].Time, AppointmentList[i].Customer);
                    Console.WriteLine(" Common Services: ");
                    AppointmentList[i].Customer.ClientDelegate();//Calling delegate
                    Console.WriteLine("");
                }
            }
            Console.WriteLine("Thank You");

        }

    }

}
    
