﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    //Interface for Client
    public delegate void ClientDelegate(); //Declaring delegate
    public interface IClient
    {//Declaring Properties and Methods.

        int Age { get; set; }
        decimal Height { get; set; }
        string Card { get; set; }
        string GetConcealedCard { get; }

        


        void HairWash();
        void HairDry();
        void HairTrim();


        string Operation();
    }
}
