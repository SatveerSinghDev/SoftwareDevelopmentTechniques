﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    //This is interface for appointments.
    public interface IAppointment : IComparable<IAppointment> //Implementing .Net interface
    {
        string Time { get; set; }
        Client Customer { get; set; }
    }
}
