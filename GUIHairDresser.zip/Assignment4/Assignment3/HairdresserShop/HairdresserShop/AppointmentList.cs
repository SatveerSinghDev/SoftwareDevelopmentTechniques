﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{   
    //This is a class for Appointment list
    public class AppointmentList : IEnumerable<IAppointment> //Implementing .Net interface
    {
        private List<IAppointment> AList = null;
        public AppointmentList()
        {
            AList= new List<IAppointment>();
        }

        public void Add(IAppointment A)
        {
            AList.Add(A);
        }

        public int Count
        {
            get { return AList.Count; }
        }

        //This is indexer
        public IAppointment this[int i]
        {
            get { return AList[i]; }
            set { AList[i] = value; }
        }

        //List is sorted according to age.
        public void Sort()
        {
            AList.Sort();
        }
        public IEnumerator<IAppointment> GetEnumerator()
        {
            return ((IEnumerable<IAppointment>)AList).GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable<IAppointment>)AList).GetEnumerator();
        }
    }
}
