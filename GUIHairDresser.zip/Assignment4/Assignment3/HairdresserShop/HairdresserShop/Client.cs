﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    // Implmented Base class as abstract.
    abstract public class  Client : IClient  //Implemented interface .
    {
        private int age;
        private decimal height;
        private string card;
        private ClientDelegate clientDelegate = null;


        public int Age { get => age; set => age = value; }
        public decimal Height { get => height; set => height = value; }
        public string Card { get => card; set => card = value; }
        
        public string GetConcealedCard { get => ConcealCard(); }
        public ClientDelegate ClientDelegate { get => clientDelegate; set => clientDelegate = value; }
        

        public Client() {
            Cdelegate();
        }
        public Client(int age,decimal height,string card)
        {
            this.age = age;
            this.height = height;
            this.card = card;
            Cdelegate();
        }

        private string ConcealCard()
        {
            StringBuilder Concealcard = new StringBuilder();
            int i = 0;
            foreach (char d in card)
            {
                i++;
                if (i > 4 && i <= 12)
                {
                    Concealcard.Append("X");
                }
                else
                {
                    Concealcard.Append(d);
                }
                // Add spaces
                if (i % 4 == 0)
                {
                    Concealcard.Append(" ");
                }
            }
            return Concealcard.ToString();
        }



        public abstract string Operation(); //Implemented supplementary methods abstract.

        public void HairWash()
        {
            Console.WriteLine(" HairWash");
        }

        public void HairDry()
        {
            Console.WriteLine(" HairDry");
        }

        public void HairTrim()
        {
            Console.WriteLine(" HairTrim");
        }

        public void Cdelegate()
        {
            clientDelegate = HairWash;
            clientDelegate += HairDry;
            clientDelegate += HairTrim;
        }

        
    }
}
