﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    public class Gentlemen: Client
    {
        private bool isTrimBeard;

        public bool IsTrimBeard { get => isTrimBeard; set => isTrimBeard = value; }

        public Gentlemen() { }

        public Gentlemen(int age, decimal height, string card, bool isTrimBeard) : base(age, height,card)
        {
            this.isTrimBeard = isTrimBeard;
        }
        public override string Operation()
        {
            return string.Format("Appointment has been booked for the Gentlemen!!!");
        }
       
        public override string ToString()
        {
            return string.Format("\n Client: Gentlemen\n Age: {0} years\n Height: {1}cm\n Credit Card Number: {2}\n He has opted {3}", Age, Height, GetConcealedCard, (IsTrimBeard) ? " trimming beard and moustaches in the additional service.\n" : "only common services.\n");
        }
    }
}
