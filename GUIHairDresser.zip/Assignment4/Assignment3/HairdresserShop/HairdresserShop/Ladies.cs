﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    public class Ladies: Client  //Derived abstract class
    {
        private bool isOccasion;

        public bool IsOccasion { get => isOccasion; set => isOccasion = value; }

        public Ladies() { }

        public Ladies(int age, decimal height, string card, bool isOccasion) : base(age, height, card)
        {
            this.isOccasion = isOccasion;
        }
        public override string Operation() //overriding method of abstract class
        {
            return string.Format("Appointment has been booked for the Lady!!!");
        }

        public override string ToString()
        {
            return string.Format("\n Client: Lady\n Age: {0} years\n Height: {1}cm\n Credit Card Number: {2}\n She has opted {3}", Age, Height, GetConcealedCard, (IsOccasion) ? " hair styling for occasion in the additional service.\n" : "only common services.\n");
        }
    }
}
