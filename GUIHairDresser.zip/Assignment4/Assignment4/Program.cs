﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HairdresserShop;
using System.Threading.Tasks;

namespace Assignment4
{
    class Program
    {   
        private int age;
        private decimal height;
        private string card;
        private string additonal;
        private string appointmentTime;
        private string clients;

        public int Length { get; }
        public int Age { get => age; set => age = value; }
        public decimal Height { get => height; set => height = value; }
        public string Card { get => card; set => card = value; }
        public string AppointmentTime { get => appointmentTime; set => appointmentTime = value; }
        public string Clients { get => clients; set => clients = value; }
        public string Additonal { get => additonal; set => additonal = value; }

        public Program(int age, decimal height, string card, string appointmentTime, string clients, string additonal)
        {
            this.age = age;
            this.height = height;
            this.card = card; 
            this.appointmentTime = appointmentTime;
            this.clients = clients;
            this.additonal = additonal;

        }
        public Program() { }
    }
}
