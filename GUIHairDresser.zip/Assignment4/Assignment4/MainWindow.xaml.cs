﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using HairdresserShop;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Assignment4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow : Window
    {
     
        public MainWindow()
        {
            InitializeComponent();
           
        }
        Program p = new Program();
        
        string appointment = String.Empty;
        string client = String.Empty;
        string additionalService = String.Empty;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //Appointment loaded into the combobox
            SortedList<int, string> AppointmentTable = new SortedList<int, string>() {
                {1, "9:00 AM"},
                {2, "10:00 AM"},
                {3, "11:00 AM"},
                {4, "12:00 PM"},
                {5, "1:00 PM"},
                {6, "2:00 PM"},
                {7, "3:00 PM"},
                {8, "4:00 PM"},
                {9, "5:00 PM"},
                {10, "6:00 PM"}

            };
            foreach (KeyValuePair<int, string> slot in AppointmentTable)
            {
                cmbData.Items.Add(slot.Value);

            }


        }
        private void RadioChecked(object sender, RoutedEventArgs e)
        {
            
            //getting selected radio buttons
            RadioButton radioButton = (RadioButton)sender;
            switch (radioButton.Name)
            {   
                
                case "C1":
                    client = C1.Content.ToString();
                    p.Clients = client;
                    break;
                case "C2":
                    client = C2.Content.ToString();
                    p.Clients = client;
                    break;
                case "C3":
                    client = C3.Content.ToString();
                    p.Clients = client;
                    break;
                case "AS1":
                    additionalService = AS1.Content.ToString();
                    p.Additonal = additionalService;
                    break;
                case "AS2":
                    additionalService = AS2.Content.ToString();
                    p.Additonal = additionalService;
                    break;
                default: break;
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int minAge;
            int maxAge;
            int agee;
            decimal heightt;
            
            bool flagAge = true;
            bool flagHeight = true;
            bool flagCredit = true;

            //getting appoint time from combobox
            switch (cmbData.SelectedIndex)
            {
                case 0:
                    appointment = cmbData.Text;
                    p.AppointmentTime = appointment;
                    break;
                case 1:
                    appointment = cmbData.Text;
                    p.AppointmentTime = appointment;
                    break;
                case 2:
                    appointment = cmbData.Text;
                    p.AppointmentTime = appointment;
                    break;
                case 3:
                    appointment = cmbData.Text;
                    p.AppointmentTime = appointment;
                    break;
                case 4:
                    appointment = cmbData.Text;
                    p.AppointmentTime = appointment;
                    break;
                case 5:
                    appointment = cmbData.Text;
                    p.AppointmentTime = appointment;
                    break;
                case 6:
                    appointment = cmbData.Text;
                    p.AppointmentTime = appointment;
                    break;
                case 7:
                    appointment = cmbData.Text;
                    p.AppointmentTime = appointment;
                    break;
                case 8:
                    appointment = cmbData.Text;
                    p.AppointmentTime = appointment;
                    break;
                case 9:
                    appointment = cmbData.Text;
                    p.AppointmentTime = appointment;
                    break;
                default: break;
            }
            //validating input values
            int.TryParse(age.Text,out agee);
            decimal.TryParse(height.Text, out heightt);
            if ((p.Clients == "Ladies") || (p.Clients == "Gentlemen"))
            {
                 minAge = 17;
                 maxAge = 70;
                if(((agee > minAge) && (agee < maxAge)) && (age.Text !=" "))
                {
                    p.Age = agee;
                    flagAge = true;
                }
                else
                {
                    age.Foreground = Brushes.Red;
                    age.BorderBrush = Brushes.Red;
                    flagAge = false;
                }
            }
            else
            {
                minAge = 4;
                maxAge = 16;
                if (((agee > minAge) && (agee < maxAge)) && (age.Text != " "))
                {
                    p.Age = agee;
                    flagAge = true;
                }
                else
                {
                    age.Foreground = Brushes.Red;
                    age.BorderBrush = Brushes.Red;
                    flagAge = false;
                }
            }
            if(((heightt > 40) && (heightt < 300)) && (height.Text != " "))
            {
                p.Height = heightt;
                flagHeight = true;

            }
            else
            {
                height.Foreground = Brushes.Red;
                height.BorderBrush = Brushes.Red;
                flagHeight = false;
            }
            p.Card = creditCard.Text;
            if (((p.Card.Length) == 16) &&(creditCard.Text != " "))
            {
                flagCredit = true;
            }
            else
            {
                creditCard.Foreground = Brushes.Red;
                creditCard.BorderBrush = Brushes.Red;
                flagCredit = false;
            }
            //if everything is correct then writting into the file
            if ((flagAge) && (flagHeight) &&(flagCredit))
            {
                
                
                FileStream fs = null;
                try
                {
                    fs = new FileStream("satveer.txt", FileMode.Append, FileAccess.Write);
                    BinaryWriter bw = new BinaryWriter(fs);
                    bw.Write(p.AppointmentTime);
                        bw.Write(p.Clients);
                        bw.Write(p.Age);
                    bw.Write(p.Height);
                    bw.Write(p.Card);
                    bw.Write(p.Additonal);
                    textBlock.Text += " Appointment booked successfully\n";
                    bw.Close();

                    
                }
                catch(IOException ioe)
                {
                    textBlock.Text = ioe.ToString();
                }
                finally
                {
                    fs.Close();
                }

                cmbData.Items.Remove(cmbData.SelectedItem);//selected appointment removed
            }

        }

        private void age_TextChanged(object sender, TextChangedEventArgs e)
        {
            age.Foreground = Brushes.Black;
            age.BorderBrush = Brushes.Black;
        }

        private void height_TextChanged(object sender, TextChangedEventArgs e)
        {
            height.Foreground = Brushes.Black;
            height.BorderBrush = Brushes.Black;
        }
        private void credit_TextChanged(object sender, TextChangedEventArgs e)
        {
            creditCard.Foreground = Brushes.Black;
            creditCard.BorderBrush = Brushes.Black;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //After clicking show button ,reading data from files
            //one customer data is already in file , we can check with show button before input
            textBlock.Text = String.Empty;
            FileStream filestream = null;
            Client customer = null;
            string fAppoint = String.Empty;
            string fClient = String.Empty;
            string fAdditional = string.Empty;
            int fAge = 0;
            decimal fHeight = 0.0m;
            string fCard = String.Empty;
            AppointmentList AppointmentList = new AppointmentList();
            
            try
            {
                filestream = new FileStream("satveer.txt", FileMode.Open, FileAccess.Read);//file location: \Assignment4\Assignment4\bin\Debug

                BinaryReader br = new BinaryReader(filestream);
                
                
                while ((br.BaseStream.Position) != (br.BaseStream.Length))
                {
                    
                    Appointment app = new Appointment();
                  
                    fAppoint = br.ReadString();
                    fClient = br.ReadString();
                    fAge = br.ReadInt32();
                    fHeight = br.ReadDecimal();
                    fCard = br.ReadString();
                    fAdditional = br.ReadString();
                    app.Time = fAppoint;
                    if (fClient == "Gentlemen")
                    {
                        Gentlemen gentle = new Gentlemen();
                        customer = new Gentlemen(fAge, fHeight, fCard, (fAdditional == "Yes") ? true : false);
                      
                    }
                    else if (fClient == "Ladies")
                    {
                        Ladies lady = new Ladies();
                        customer = new Ladies(fAge, fHeight, fCard, (fAdditional == "Yes") ? true : false);
                     }
                    else
                    {
                        Children child = new Children();
                        customer = new Children(fAge, fHeight, fCard, (fAdditional == "Yes") ? true : false, (fAdditional == "Yes") ? true : false);
                    }
                    app.Customer = customer;
                    AppointmentList.Add(app);
                    AppointmentList.Sort();
                   
                }

                br.Close();
            }
            catch (IOException ioe)
            {
                textBlock.Text = ioe.ToString();
            }
            finally
            {
                filestream.Close();
            }
            //Data showing in the textblock
            for(int i= 0; i < AppointmentList.Count; i++)
            {
                if (AppointmentList[i].Customer != null)
                {
                    int j = i + 1;
                    textBlock.Text +=" ["+ j + "] "+ AppointmentList[i].Customer.Operation();
                    textBlock.Text += "\n Appointment Time : " + AppointmentList[i].Time + "\n";
                    textBlock.Text += " We offer common services for all ages and genders\n";
                    textBlock.Text += " *Hair Wash    *Hair Dry   *Hair Trim";
                    textBlock.Text += AppointmentList[i].Customer;
                    textBlock.Text += "\n";
                       
                    }
                }
        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {
            //this is for clear button
            textBlock.Text = String.Empty;
            age.Text = String.Empty;
            height.Text = String.Empty;
            creditCard.Text = String.Empty;
            C1.IsChecked = false;
            C2.IsChecked = false;
            C3.IsChecked = false;
            AS1.IsChecked = false;
            AS2.IsChecked = false;
            cmbData.SelectedIndex = -1;
        }

       
    }
}
