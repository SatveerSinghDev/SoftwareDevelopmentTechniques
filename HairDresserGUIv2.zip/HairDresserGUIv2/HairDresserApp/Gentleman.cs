﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairDresserApp
{
    public class Gentleman : Client
    {
        private bool needFacialTrim;

        public bool NeedFacialTrim { get => needFacialTrim; set => needFacialTrim = value; }

        public Gentleman() { }
        public Gentleman(string name, int age, decimal height, string creditCard, bool needFacialTrim) : base(name, age, height, creditCard)
        {
            this.needFacialTrim = needFacialTrim;
        }

        public override void SpecialService()
        {
            Console.WriteLine($"{(needFacialTrim ? "" : "No ")}Beard and moustache trimming");
        }

        public override string ToString()
        {
            return String.Format($"Gentleman's Name: {Name}, Age: {Age}, Height: {Height} ft, Credit Card: {MaskCreditCard()}");
        }
    }
}
