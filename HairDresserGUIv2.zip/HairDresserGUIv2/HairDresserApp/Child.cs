﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairDresserApp
{
    public class Child : Client
    {
        private bool needAdjustableChair;

        public bool NeedAdjustableChair { get => needAdjustableChair; set => needAdjustableChair = value; }

        public Child() { }
        public Child(string name, int age, decimal height, string creditCard, bool needAdjustableChair) : base(name, age, height, creditCard)
        {
            this.needAdjustableChair = needAdjustableChair;
        }


        public override void SpecialService()
        {
            Console.WriteLine($"{(needAdjustableChair ? "" : "No ")}Sensitive Trimmer and Adjustable Chair");
        }

        public override string ToString()
        {
            return String.Format($"Child's Name: {Name}, Age: {Age}, Height: {Height} ft, Credit Card: {MaskCreditCard()}");
        }
    }
}
