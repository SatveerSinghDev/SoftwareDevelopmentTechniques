﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairDresserApp
{
    public interface IAppointment : IComparable<IAppointment>
    {
        string Time { get; set; }
        string Type { get; set; }
        Client Client { get; set; }
    }
}
