﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairDresserApp
{
    public class Appointment : IAppointment
    {

        private string time;
        private string type;
        private Client client;

        public string Time { get => time; set => time = value; }
        public string Type { get => type; set => type = value; }
        public Client Client { get => client; set => client = value; }

        public int CompareTo(IAppointment other)
        {
            return Client.Age.CompareTo(other.Client.Age);
        }
    }
}
