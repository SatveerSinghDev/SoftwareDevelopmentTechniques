﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairDresserApp
{
    public class Lady : Client
    {
        private bool neddHairStyling;

        public bool NeedHairStyling { get => neddHairStyling; set => neddHairStyling = value; }

        public Lady() { }
        public Lady(string name, int age, decimal height, string creditCard, bool needHairStyling) : base(name, age, height, creditCard)
        {
            this.NeedHairStyling = needHairStyling;
        }

        public override void SpecialService()
        {
            Console.WriteLine($"{(NeedHairStyling ? "" : "No ")}Hair styling");
        }

        public override string ToString()
        {
            return String.Format($"Lady's Name: {Name}, Age: {Age}, Height: {Height} ft, Credit Card: {MaskCreditCard()}");
        }
    }
}
