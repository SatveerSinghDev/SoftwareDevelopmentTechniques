﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairDresserApp
{
    public interface IClient
    {
        string Name { get; set; }
        int Age { get; set; }
        decimal Height { get; set; }
        string CreditCard { get; set; }

        void HairWash();
        void HairTrim();
        void HairDye();
        void SpecialService();
        string MaskCreditCard();
    }
}
