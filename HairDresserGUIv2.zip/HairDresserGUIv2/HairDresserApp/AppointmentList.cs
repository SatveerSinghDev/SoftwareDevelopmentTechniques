﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace HairDresserApp
{
    [XmlRoot("AppointmentList")]
    [XmlInclude(typeof(Gentleman))]
    [XmlInclude(typeof(Lady))]
    [XmlInclude(typeof(Child))]
    public class AppointmentList
    {
        List<Appointment> appointments;

        public int Count { get => Appointments.Count; }

        [XmlArray("Appointments")]
        [XmlArrayItem("Appointment", typeof(Appointment))]
        public List<Appointment> Appointments { get => appointments; set => appointments = value; }

        public AppointmentList()
        {
            Appointments = new List<Appointment>();
        }

        public Appointment this[int i]
        {
            get { return Appointments[i];  }
            set { Appointments[i] = value; }
        }

        public void Add(Appointment appointment)
        {
            Appointments.Add(appointment);
        }

        public void Remove(Appointment appointment)
        {
            Appointments.Remove(appointment);
        }

        public IEnumerator<IAppointment> GetEnumerator()
        {
            return ((IEnumerable<IAppointment>)Appointments).GetEnumerator();
        }


        public void Sort()
        {
            Appointments.Sort();
        }
    }
}
