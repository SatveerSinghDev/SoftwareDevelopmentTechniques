﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairDresserApp
{
    public abstract class Client: IClient
    {
        private string name;
        private int age;
        private decimal height;
        private string creditCard;

        public string Name { get => name; set => name = value; }
        public int Age { get => age; set => age = value; }
        public decimal Height { get => height; set => height = value; }
        public string CreditCard { get => creditCard; set => creditCard = value; }

        public Client() { }

        public Client(string name, int age, decimal height, string creditCard)
        {
            this.name = name;
            this.age = age;
            this.height = height;
            this.creditCard = creditCard;
        }

        public void HairWash()
        {
            Console.WriteLine("Hair Wash");
        }

        public void HairTrim()
        {
            Console.WriteLine("Hair Trim");
        }

        public void HairDye()
        {
            Console.WriteLine("Hair Dye");
        }

        public abstract void SpecialService();


        public string MaskCreditCard()
        {
            StringBuilder sb = new StringBuilder();
            int index = 0;
            foreach(char c in creditCard)
            {
                index++;
                // replace 5th to 12th characters with X else leave as it is
                if ((index > 4) && (index <= 12))
                {
                    sb.Append("X");
                }
                else
                {
                    sb.Append(c);
                }
                // Add space after every 4th character
                if(index % 4 == 0)
                {
                    sb.Append(" ");
                }
            }
            return sb.ToString();
        }
    }
}
