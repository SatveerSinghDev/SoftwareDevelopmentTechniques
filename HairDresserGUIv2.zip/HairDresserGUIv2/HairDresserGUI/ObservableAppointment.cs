﻿using HairDresserApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairDresserGUI
{
    public class ObservableAppointment
    {
        private Appointment appointment;

        private string specialRequest;

        public Appointment Appointment { get => appointment; set => appointment = value; }
        public string SpecialRequest { get => specialRequest; set => specialRequest = value; }
    }
}
