﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace HairDresserGUI
{
    class CreditCardRule : ValidationRule
    {
        int count;

        public int Count { get => count; set => count = value; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (value.ToString().Length != 16)
            {
                return new ValidationResult(false, "Invalid credit card length.");
            }

            foreach (char c in value.ToString())
            {
                if (!Char.IsDigit(c))
                {
                    return new ValidationResult(false, "Invalid credit card number."); ;
                }
            }

            return ValidationResult.ValidResult;
        }

    }
}
