﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace HairDresserGUI
{
    class AgeRule : ValidationRule
    {
        int min;
        int max;

        public int Min { get => min; set => min = value; }
        public int Max { get => max; set => max = value; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            int age;
            if (!int.TryParse(value.ToString(), out age))
            {
                return new ValidationResult(false, "Invalid age type.");
            }

            if (age < min || age > max)
            {
                return new ValidationResult(false, "Age must be between 1 to 100.");
            }

            return ValidationResult.ValidResult;
        }

    }
}
