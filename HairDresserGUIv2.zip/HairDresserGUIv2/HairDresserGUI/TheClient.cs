﻿using HairDresserApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairDresserGUI
{
    public class TheClient : Client
    {
        public override void SpecialService()
        {
            
        }
    }
}
