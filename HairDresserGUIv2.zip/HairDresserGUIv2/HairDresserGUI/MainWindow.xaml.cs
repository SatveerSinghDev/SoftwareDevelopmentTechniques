﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections;
using HairDresserApp;
using System.IO;
using System.Xml.Serialization;
using System.Collections.ObjectModel;

namespace HairDresserGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ArrayList slotsTable = new ArrayList() {
            "8:00 AM",
            "8:30 AM",
            "9:00 AM",
            "9:30 AM",
            "10:00 AM",
            "10:30 AM",
            "11:00 AM",
            "11:30 AM",
            "12:00 PM",
            "12:30 PM",
            "1:00 PM",
            "1:30 PM",
            "2:00 PM",
            "2:30 PM",
            "3:00 PM",
            "3:30 PM",
            "4:00 PM",
            "4:30 PM",
            "5:00 PM"
            };

        ObservableCollection<ObservableAppointment> displayAppointments = null;
        Appointments appointmentList = new Appointments();
        TheClient theClient = new TheClient();

        public ObservableCollection<ObservableAppointment> DisplayAppointments { get => displayAppointments; set => displayAppointments = value; }
        public TheClient TheClient { get => theClient; set => theClient = value; }

        public MainWindow()
        {
            InitializeComponent();
            specialRequestForm.Visibility = Visibility.Collapsed;

            DisplayAppointments = new ObservableCollection<ObservableAppointment>();
            DisplayAppointments.Clear();
            DataContext = this;

            RetriveData();
            // load slots table
            foreach (String slot in slotsTable)
            {
                timeSlotsInput.Items.Add(slot);
            }

            foreach (ObservableAppointment appointment in appointmentList)
            {
                if (timeSlotsInput.Items.Contains(appointment.Appointment.Time))
                {
                    timeSlotsInput.Items.Remove(appointment.Appointment.Time);
                }
            }

        }

        private void ClientTypeChecked(object sender, RoutedEventArgs e)
        {
            RadioButton clientType = (RadioButton)sender;
            specialRequestForm.Visibility = Visibility.Visible;
            switch (clientType.Name)
            {
                case "gentleman":
                    {
                        specialRequestLabel.Content = "Do you need beard and moustache trimming?";
                        break;
                    }
                case "lady":
                    {
                        specialRequestLabel.Content = "Do you need additional hair styling for occasions?";
                        break;
                    }
                case "child":
                    {
                        specialRequestLabel.Content = "Do you need sensitive trimmers and seats adjustable for height?";
                        break;
                    }
                default:
                    {
                        specialRequestForm.Visibility = Visibility.Hidden;
                        break;
                    }
            }
        }

        private void AddAppointment_Click(object sender, RoutedEventArgs e)
        {
            bool validated = true;

            if (!IsClientTypeChecked())
            {
                gentleman.Foreground = Brushes.Red;
                lady.Foreground = Brushes.Red;
                child.Foreground = Brushes.Red;
                validated = false;
            }
            if (nameInput.Text == "")
            {
                nameInput.BorderBrush = Brushes.Red;
                validated = false;
            }
            int age = 0;
            if (!int.TryParse(ageInput.Text, out age) || (age < 1) || (age > 100))
            {
                ageInput.BorderBrush = Brushes.Red;
                validated = false;
            }

            decimal height;
            if (!decimal.TryParse(heightInput.Text, out height) || (height < 1m) || (height > 7m))
            {
                heightInput.BorderBrush = Brushes.Red;
                validated = false;
            }
            if ((creditCardInput.Text.Length != 16) || !ValidateCreditCard(creditCardInput.Text))
            {
                creditCardInput.BorderBrush = Brushes.Red;
                validated = false;
            }
            if (timeSlotsInput.SelectionBoxItem.ToString() == "")
            {
                timeSlotsInputBorder.BorderThickness = new Thickness(1);
                timeSlotsInputBorder.BorderBrush = Brushes.Red;
                validated = false;
            }
            if (!IsSpecialRequestChecked())
            {
                specialRequest.Foreground = Brushes.Red;
                noSpecialRequest.Foreground = Brushes.Red;
                validated = false;
            }
            if (validated)
            {
                string time = timeSlotsInput.SelectionBoxItem.ToString();
                Client client = null;
                string type = "";
                string special = "";
                if ((bool)gentleman.IsChecked)
                {
                    client = new Gentleman(nameInput.Text, age, height, creditCardInput.Text, (bool)specialRequest.IsChecked ? true : false);
                    type = "Gentleman";
                    special = (bool)specialRequest.IsChecked ? "Beard Trimming" : "No Beard Trimming";
                }
                else if ((bool)lady.IsChecked)
                {
                    client = new Lady(nameInput.Text, age, height, creditCardInput.Text, (bool)specialRequest.IsChecked ? true : false);
                    type = "Lady";
                    special = (bool)specialRequest.IsChecked ? "Hair Styling" : "No Hair Styling";
                }
                else if ((bool)child.IsChecked)
                {
                    client = new Child(nameInput.Text, age, height, creditCardInput.Text, (bool)specialRequest.IsChecked ? true : false);
                    type = "Child";
                    special = (bool)specialRequest.IsChecked ? "Sensitive Trimmer and Adjustable Chair" : "No Sensitive Trimmer and Adjustable Chair";
                }
                else
                {
                    MessageBox.Show("Something went wrong!");
                    type = null;
                }

                Appointment appointment = new Appointment();
                appointment.Type = type;
                appointment.Time = time;
                appointment.Client = client;

                // Add to observable appointment
                ObservableAppointment myAppointment = new ObservableAppointment();
                myAppointment.SpecialRequest = special;
                myAppointment.Appointment = appointment;
                DisplayAppointments.Add(myAppointment);
                appointmentList.Add(myAppointment);


                if (timeSlotsInput.Items.Contains(time))
                {
                    timeSlotsInput.Items.Remove(time);
                }
                MessageBox.Show("Appointment added successfully.");
                ResetFields();


            }
        }

        private void SaveAppointment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                WriteData();
                MessageBox.Show("Data Saved Successfully.");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Cannot save data.");
            }
        }

        private void RetriveData()
        {
            ReadData();
            DisplayAppointments.Clear();
            /*var apps = from appointment in appointmentList
                       select appointment;*/
            foreach (ObservableAppointment registeredAppointment in appointmentList)
            {
                DisplayAppointments.Add(registeredAppointment);
            }
        }

        private void DisplayAppointment_Click(object sender, RoutedEventArgs e)
        {
            RetriveData();

        }

        private void WriteData()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Appointments));
            TextWriter textWriter = new StreamWriter("appointments.xml");
            serializer.Serialize(textWriter, appointmentList);
            textWriter.Close();
        }
        private void ReadData()
        {
            TextReader textReader = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Appointments));
                textReader = new StreamReader("appointments.xml");
                appointmentList = (Appointments)serializer.Deserialize(textReader);
                textReader.Close();
            }
            catch (FileNotFoundException e)
            {
            }
        }

        private bool IsClientTypeChecked()
        {
            if (((bool)gentleman.IsChecked) || ((bool)lady.IsChecked) || ((bool)child.IsChecked))
            {
                return true;
            }
            return false;
        }

        private bool IsSpecialRequestChecked()
        {
            if (((bool)specialRequest.IsChecked) || ((bool)noSpecialRequest.IsChecked))
            {
                return true;
            }
            return false;
        }

        private bool ValidateCreditCard(string cardNumber)
        {
            foreach (char c in cardNumber)
            {
                if (!Char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void ResetFields()
        {
            gentleman.IsChecked = false;
            lady.IsChecked = false;
            child.IsChecked = false;
            nameInput.Text = "";
            ageInput.Text = "";
            heightInput.Text = "";
            creditCardInput.Text = "";
            specialRequest.IsChecked = false;
            noSpecialRequest.IsChecked = false;
        }
        private void ResetBrush()
        {
            gentleman.Foreground = Brushes.Gray;
            lady.Foreground = Brushes.Gray;
            child.Foreground = Brushes.Gray;
            nameInput.BorderBrush = Brushes.Gray;
            ageInput.BorderBrush = Brushes.Gray;
            heightInput.BorderBrush = Brushes.Gray;
            creditCardInput.BorderBrush = Brushes.Gray;
            timeSlotsInputBorder.BorderThickness = new Thickness(1);
            timeSlotsInputBorder.BorderBrush = Brushes.Gray;
            specialRequest.Foreground = Brushes.Gray;
            noSpecialRequest.Foreground = Brushes.Gray;
        }


        private void ResetBrush(object sender, KeyEventArgs e)
        {
            ResetBrush();
        }

        private void ResetBrush_DropDownOpened(object sender, EventArgs e)
        {
            ResetBrush();
        }

        private void ClientType_Click(object sender, RoutedEventArgs e)
        {
            ResetBrush();
        }

        private void SpecialRequest_Click(object sender, RoutedEventArgs e)
        {
            ResetBrush();
        }

        private void Filter_Click(object sender, RoutedEventArgs e)
        {
            var query = from ObservableAppointment in DisplayAppointments
                        where ObservableAppointment.Appointment.Client.Name.ToLower().Contains(filterInput.Text.ToLower().Trim())
                        select ObservableAppointment;
            DataTable.ItemsSource = query;
        }
    }
}
