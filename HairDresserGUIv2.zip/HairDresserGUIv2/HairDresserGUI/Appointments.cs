﻿using HairDresserApp;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace HairDresserGUI
{
    [XmlRoot("AppointmentList")]
    [XmlInclude(typeof(Gentleman))]
    [XmlInclude(typeof(Lady))]
    [XmlInclude(typeof(Child))]
    public class Appointments
    {
        List<ObservableAppointment> myAppointments;

        public int Count { get => MyAppointments.Count; }

        [XmlArray("Appointments")]
        [XmlArrayItem("Appointment", typeof(ObservableAppointment))]
        public List<ObservableAppointment> MyAppointments { get => myAppointments; set => myAppointments = value; }

        public Appointments()
        {
            MyAppointments = new List<ObservableAppointment>();
        }

        public ObservableAppointment this[int i]
        {
            get { return MyAppointments[i]; }
            set { MyAppointments[i] = value; }
        }

        public void Add(ObservableAppointment appointment)
        {
            MyAppointments.Add(appointment);
        }

        public void Remove(ObservableAppointment appointment)
        {
            MyAppointments.Remove(appointment);
        }

        public IEnumerator<ObservableAppointment> GetEnumerator()
        {
            return ((IEnumerable<ObservableAppointment>)MyAppointments).GetEnumerator();
        }


        public void Sort()
        {
            MyAppointments.Sort();
        }
    }
}
