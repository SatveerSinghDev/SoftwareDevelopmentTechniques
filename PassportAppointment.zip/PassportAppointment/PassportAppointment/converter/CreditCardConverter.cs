﻿using PassportAppointment.lib;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace PassportAppointment.converter
{
    public class CreditCardConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return MaskCreditCard(value.ToString());
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return true;
        }

        private string MaskCreditCard(string value)
        {
            StringBuilder sb = new StringBuilder();
            int index = 0;
            foreach (char c in value)
            {
                index++;
                // replace 5th to 12th characters with X else leave as it is
                if ((index > 4) && (index <= 12))
                {
                    sb.Append("*");
                }
                else
                {
                    sb.Append(c);
                }
                // Add space after every 4th character
                if (index % 4 == 0)
                {
                    sb.Append(" ");
                }
            }
            return sb.ToString();
        }
    }
}
