﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassportAppointment.lib
{
    public class NormalPassport : Passport
    {
        private bool hasDelivery;

        public NormalPassport()
        {
        }

        public NormalPassport(string firstName, string lastName, string gender, string dateOfBirth, string address, string email, string creditCard, bool hasDelivery) : base(firstName, lastName, gender, dateOfBirth, address, email, creditCard)
        {
            this.hasDelivery = hasDelivery;
        }

        public bool HasDelivery { get => hasDelivery; set => hasDelivery = value; }

        public override string ExtraService()
        {
            return string.Format($"{(hasDelivery ? "Home Delivery" : "Pickup")}");
        }
    }
}
