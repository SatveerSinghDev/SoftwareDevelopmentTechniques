﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassportAppointment.lib
{
    public abstract class Passport : IPassport
    {

        private string firstName;
        private string lastName;
        private string gender;
        private string dateOfBirth;
        private string address;
        private string email;
        private string creditCard;

        public Passport()
        {
        }

        protected Passport(string firstName, string lastName, string gender, string dateOfBirth, string address, string email, string creditCard)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.gender = gender;
            this.dateOfBirth = dateOfBirth;
            this.address = address;
            this.email = email;
            this.creditCard = creditCard;
        }

        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Gender { get => gender; set => gender = value; }
        public string DateOfBirth { get => dateOfBirth; set => dateOfBirth = value; }
        public string Address { get => address; set => address = value; }
        public string Email { get => email; set => email = value; }
        public string CreditCard { get => creditCard; set => creditCard = value; }

        public abstract string ExtraService();
    }
}
