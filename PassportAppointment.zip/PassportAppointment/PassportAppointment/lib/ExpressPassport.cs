﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassportAppointment.lib
{
    public class ExpressPassport : Passport
    {
        private bool oneDayService;

        public ExpressPassport()
        {
        }

        public ExpressPassport(string firstName, string lastName, string gender, string dateOfBirth, string address, string email, string creditCard, bool oneDayService) : base(firstName, lastName, gender, dateOfBirth, address, email, creditCard)
        {
            this.OneDayService = oneDayService;
        }

        public bool OneDayService { get => oneDayService; set => oneDayService = value; }

        public override string ExtraService()
        {
            return string.Format($"{(oneDayService ? "1 Day Service" : "3 Day Service")}");
        }
    }
}
