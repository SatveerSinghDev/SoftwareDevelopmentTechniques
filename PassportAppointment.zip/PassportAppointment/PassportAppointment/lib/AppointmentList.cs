﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace PassportAppointment.lib
{
    [XmlRoot("AppointmentList")]
    [XmlInclude(typeof(NormalPassport))]
    [XmlInclude(typeof(ExpressPassport))]
    public class AppointmentList
    {
        List<Appointment> appointments;

        public AppointmentList()
        {
            Appointments = new List<Appointment>();
        }


        [XmlArray("Appointments")]
        [XmlArrayItem("Appointment", typeof(Appointment))]
        public List<Appointment> Appointments { get => appointments; set => appointments = value; }


        public Appointment this[int i]
        {
            get { return Appointments[i];  }
            set { Appointments[i] = value; }
        }

        public IEnumerator<Appointment> GetEnumerator()
        {
            return ((IEnumerable<Appointment>)Appointments).GetEnumerator();
        }

        public void Add(Appointment appointment)
        {
            Appointments.Add(appointment);
        }

        public void Remove(Appointment appointment)
        {
            Appointments.Remove(appointment);
        }
    }
}
