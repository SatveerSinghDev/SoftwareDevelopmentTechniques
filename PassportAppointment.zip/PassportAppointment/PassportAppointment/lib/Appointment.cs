﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassportAppointment.lib
{
    public class Appointment
    {
        private string date;
        private string time;
        private string type;
        private Passport passport;
        private string extraService;
        
        public string Date { get => date; set => date = value; }
        public string Time { get => time; set => time = value; }
        public string Type { get => type; set => type = value; }
        public Passport Passport { get => passport; set => passport = value; }
        public string ExtraService { get => extraService; set => extraService = value; }
    }
}
