﻿using PassportAppointment.lib;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace PassportAppointment
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        // Appointment slots
        List<string> timeSlots = new List<string>()
        {
            "8:00 AM",
            "8:30 AM",
            "9:00 AM",
            "9:30 AM",
            "10:00 AM",
            "10:30 AM",
            "11:00 AM",
            "11:30 AM",
            "12:00 PM",
            "12:30 PM",
            "1:00 PM",
            "1:30 PM",
            "2:00 PM",
            "2:30 PM",
            "3:00 PM",
            "3:30 PM",
            "4:00 PM",
            "4:30 PM",
            "5:00 PM"
        };

        ObservableCollection<Appointment> displayAppointments = null;
        AppointmentList appointmentList = new AppointmentList();

        public ObservableCollection<Appointment> DisplayAppointments { get => displayAppointments; set => displayAppointments = value; }

        public MainWindow()
        {
            InitializeComponent();

            DataContext = this;

            DisplayAppointments = new ObservableCollection<Appointment>();

            // load timeslot combobox
            foreach (String slot in timeSlots)
            {
                timeSlotsInput.Items.Add(slot);
            }

            // remove occupied time slot
            foreach (Appointment appointment in appointmentList)
            {
                if (timeSlotsInput.Items.Contains(appointment.Time) && dateSlotInput.Text == appointment.Date)
                {
                    timeSlotsInput.Items.Remove(appointment.Time);
                }
            }

            LoadData();

            // load defaults
            normal.IsChecked = true;
            extraService.IsChecked = true;
            male.IsChecked = true;

        }

        private void ReadData()
        {
            TextReader textReader = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(AppointmentList));
                textReader = new StreamReader("appointments.xml");
                appointmentList = (AppointmentList)serializer.Deserialize(textReader);
                textReader.Close();
            }
            catch (Exception e)
            {
                
            }
        }

        private void WriteData()
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(AppointmentList));
                TextWriter textWriter = new StreamWriter("appointments.xml");
                serializer.Serialize(textWriter, appointmentList);
                textWriter.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
        }

        private void LoadData()
        {
            ReadData();
            DisplayAppointments.Clear();
            foreach (Appointment registeredAppointment in appointmentList)
            {
                DisplayAppointments.Add(registeredAppointment);
            }
        }

        private void AddAppointment_Click(object sender, RoutedEventArgs e)
        {
            ResetStyle();
            bool validated = true;

            if(dateSlotInput.Text == "")
            {
                dateSlotInput.BorderBrush = Brushes.Red;
                dateSlotInput.ToolTip = "Date cannot be empty.";
                dateSlotInput.BorderThickness = new Thickness(2);
                validated = false;
            }

            if (timeSlotsInput.SelectedItem == null)
            {
                timeSlotsInputBorder.BorderThickness = new Thickness(2);
                timeSlotsInputBorder.BorderBrush = Brushes.Red;
                timeSlotsInput.BorderBrush = Brushes.Red;
                timeSlotsInput.ToolTip = "Time cannot be empty.";
                timeSlotsInput.BorderThickness = new Thickness(2);
                validated = false;
            }

            if (firstNameInput.Text == "")
            {
                firstNameInput.BorderBrush = Brushes.Red;
                firstNameInput.ToolTip = "First name cannot be empty.";
                firstNameInput.BorderThickness = new Thickness(2);
                validated = false;
            }

            if (lastNameInput.Text == "")
            {
                lastNameInput.BorderBrush = Brushes.Red;
                lastNameInput.ToolTip = "Last name cannot be empty";
                lastNameInput.BorderThickness = new Thickness(2);
                validated = false;
            }

            if (dateOfBirthInput.Text == "")
            {
                dateOfBirthInput.BorderBrush = Brushes.Red;
                dateOfBirthInput.ToolTip = "Date of birth cannot be empty.";
                dateOfBirthInput.BorderThickness = new Thickness(2);
                validated = false;
            }

            if (addressInput.Text.Length > 50 || addressInput.Text.Length < 1)
            {
                addressInput.BorderBrush = Brushes.Red;
                addressInput.ToolTip = "Invalid address length.";
                addressInput.BorderThickness = new Thickness(2);
                validated = false;
            }

            if (emailInput.Text == "")
            {
                emailInput.BorderBrush = Brushes.Red;
                emailInput.ToolTip = "Email cannot be empty.";
                emailInput.BorderThickness = new Thickness(2);
                validated = false;
            }

            if ((creditCardInput.Text.Length != 16) || !ValidateCreditCard(creditCardInput.Text))
            {
                creditCardInput.BorderBrush = Brushes.Red;
                creditCardInput.ToolTip = "Invalid Credit Card.";
                creditCardInput.BorderThickness = new Thickness(2);
                validated = false;
            }

            int index = dataTable.SelectedIndex;
            if (validated)
            {
                string time = timeSlotsInput.SelectedItem.ToString();
                string date = dateSlotInput.Text;
                Passport passport = null;
                string type = "";
                string extra = "";
                
                if((bool)normal.IsChecked)
                {
                    passport = new NormalPassport(firstNameInput.Text, lastNameInput.Text, getGender(), dateOfBirthInput.Text, addressInput.Text, emailInput.Text, creditCardInput.Text, (bool)extraService.IsChecked ? true : false);
                    type = "Normal";
                    extra = (bool)extraService.IsChecked ? "Home Delivery" : "Pickup";
                }
                else if ((bool)express.IsChecked)
                {
                    passport = new ExpressPassport(firstNameInput.Text, lastNameInput.Text, getGender(), dateOfBirthInput.Text, addressInput.Text, emailInput.Text, creditCardInput.Text, (bool)extraService.IsChecked ? true : false);
                    type = "Express";
                    extra = (bool)extraService.IsChecked ? "One Day Service" : "Three Days Service";
                }
                else
                {
                    MessageBox.Show("Something went wrong!");
                    type = null;
                    extra = "";
                }

                Appointment appointment = null;
                if(index > -1)
                {
                    saveAppointment.Content = index;
                    appointment = DisplayAppointments[index];
                    appointment.Date = date;
                    appointment.Time = time;
                    appointment.Type = type;
                    appointment.Passport = passport;
                    appointment.ExtraService = extra;
                    DisplayAppointments.Clear();
                    foreach(Appointment appointment1 in appointmentList)
                    {
                        DisplayAppointments.Add(appointment1);
                    }
                }
                else
                {
                    appointment = new Appointment();
                    saveAppointment.Content = index;
                    appointment.Date = date;
                    appointment.Time = time;
                    appointment.Type = type;
                    appointment.Passport = passport;
                    appointment.ExtraService = extra;
                    DisplayAppointments.Add(appointment);
                    appointmentList.Add(appointment);
                    appointment = new Appointment();
                }

                dataTable.SelectedIndex = -1;
                ResetFields();
                WriteData();
            }
        }

        private string getGender()
        {
            if((bool)male.IsChecked)
            {
                return "Male";
            }
            else if((bool)female.IsChecked)
            {
                return "Female";
            }
            else if((bool)other.IsChecked)
            {
                return "Other";
            }
            else
            {
                return "";
            }
        }

        private void ResetFields()
        {
            saveAppointment.Content = "Add Appointment";
            dateSlotInput.Text = "";
            timeSlotsInput.SelectedItem = null;
            normal.IsChecked = true;
            express.IsChecked = false;
            male.IsChecked = true;
            female.IsChecked = false;
            other.IsChecked = false;
            extraService.IsChecked = true;
            noExtraService.IsChecked = false;
            firstNameInput.Text = "";
            lastNameInput.Text = "";
            dateOfBirthInput.Text = "";
            addressInput.Text = "";
            emailInput.Text = "";
            creditCardInput.Text = "";
        }

        private void ResetStyle()
        {
            // reset color
            dateSlotInput.BorderBrush = Brushes.Gray;
            timeSlotsInput.BorderBrush = Brushes.Gray;
            firstNameInput.BorderBrush = Brushes.Gray;
            lastNameInput.BorderBrush = Brushes.Gray;
            dateOfBirthInput.BorderBrush = Brushes.Gray;
            addressInput.BorderBrush = Brushes.Gray;
            emailInput.BorderBrush = Brushes.Gray;
            creditCardInput.BorderBrush = Brushes.Gray;
            timeSlotsInputBorder.BorderBrush = Brushes.Gray;

            // reset tooltips
            dateSlotInput.ToolTip = null;
            timeSlotsInput.ToolTip = null;
            firstNameInput.ToolTip = null;
            lastNameInput.ToolTip = null;
            dateOfBirthInput.ToolTip = null;
            addressInput.ToolTip = null;
            emailInput.ToolTip = null;
            creditCardInput.ToolTip = null;

            // reset thickness
            dateSlotInput.BorderThickness = new Thickness(1);
            timeSlotsInput.BorderThickness = new Thickness(1);
            firstNameInput.BorderThickness = new Thickness(1);
            lastNameInput.BorderThickness = new Thickness(1);
            dateOfBirthInput.BorderThickness = new Thickness(1);
            addressInput.BorderThickness = new Thickness(1);
            emailInput.BorderThickness = new Thickness(1);
            creditCardInput.BorderThickness = new Thickness(1);
            timeSlotsInputBorder.BorderThickness = new Thickness(1);


        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            var query = from Appointment in DisplayAppointments
                        where Appointment.Passport.FirstName.ToLower().Contains(searchInput.Text.ToLower().Trim()) ||
                        Appointment.Passport.LastName.ToLower().Contains(searchInput.Text.ToLower().Trim()) ||
                        Appointment.Passport.DateOfBirth.ToLower().Contains(searchInput.Text.ToLower().Trim()) ||
                        Appointment.Passport.Gender.ToLower().Contains(searchInput.Text.ToLower().Trim()) ||
                        Appointment.Passport.Address.ToLower().Contains(searchInput.Text.ToLower().Trim()) ||
                        Appointment.Passport.Email.ToLower().Contains(searchInput.Text.ToLower().Trim()) ||
                        Appointment.Type.ToLower().Contains(searchInput.Text.ToLower().Trim()) ||
                        Appointment.Date.ToLower().Contains(searchInput.Text.ToLower().Trim())
                        select Appointment;
            dataTable.ItemsSource = query;
        }


        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            Appointment row = (Appointment)dataTable.SelectedItem;
            int index = dataTable.SelectedIndex;
            if (row != null)
            {
                saveAppointment.Content = "Update Appointment";
                dateSlotInput.Text = row.Date;
                timeSlotsInput.SelectedItem = row.Time;
                if (row.Type == "Normal")
                {
                    normal.IsChecked = true;
                    express.IsChecked = false;
                }
                else
                {
                    normal.IsChecked = false;
                    express.IsChecked = true;
                }

                if (row.Passport.Gender == "Male")
                {
                    male.IsChecked = true;
                    female.IsChecked = false;
                    other.IsChecked = false;
                }
                else if (row.Passport.Gender == "Female")
                {
                    male.IsChecked = false;
                    female.IsChecked = true;
                    other.IsChecked = false;
                }
                else
                {
                    male.IsChecked = true;
                    female.IsChecked = false;
                    other.IsChecked = true;
                }

                if(row.Passport.GetType() == typeof(NormalPassport))
                {
                    NormalPassport passport = row.Passport as NormalPassport;
                    if (passport.HasDelivery)
                    {
                        extraService.IsChecked = true;
                        noExtraService.IsChecked = false;
                    }
                    else
                    {
                        extraService.IsChecked = false;
                        noExtraService.IsChecked = true;
                    }
                    extraserviceLabel.Content = "Delivery Type:";
                    extraService.Content = "Home Delivery";
                    noExtraService.Content = "Pickup";

                }
                else if(row.Passport.GetType() == typeof(ExpressPassport))
                {
                    ExpressPassport passport = row.Passport as ExpressPassport;
                    if (passport.OneDayService)
                    {
                        extraService.IsChecked = true;
                        noExtraService.IsChecked = false;
                    }
                    else
                    {
                        extraService.IsChecked = false;
                        noExtraService.IsChecked = true;
                    }
                    extraserviceLabel.Content = "Duration:";
                    extraService.Content = "One Day Service";
                    noExtraService.Content = "Three Days Service";
                }

                firstNameInput.Text = row.Passport.FirstName;
                lastNameInput.Text = row.Passport.LastName;
                dateOfBirthInput.Text = row.Passport.DateOfBirth;
                addressInput.Text = row.Passport.Address;
                emailInput.Text = row.Passport.Email;
                creditCardInput.Text = row.Passport.CreditCard;
            }
            
        }

        private void ReloadButton_Click(object sender, RoutedEventArgs e)
        {
            DisplayAppointments.Clear();
            LoadData();
        }

            private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            Appointment row = (Appointment)dataTable.SelectedItem;
            if(row != null)
            {
                DisplayAppointments.Remove(row);
                appointmentList.Remove(row);
                WriteData();
            }
        }


        private void PassportType_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton passportType = (RadioButton)sender;
            switch (passportType.Name)
            {
                case "normal":
                    {
                        extraserviceLabel.Content = "Delivert Type:";
                        extraService.Content = "Home Delivery";
                        noExtraService.Content = "Pickup";
                        break;
                    }
                case "express":
                    {
                        extraserviceLabel.Content = "Duation:";
                        extraService.Content = "One Day Service";
                        noExtraService.Content = "Three Days Service";
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }

        // validate credit card
        private bool ValidateCreditCard(string cardNumber)
        {
            foreach (char c in cardNumber)
            {
                if (!Char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }
    }
}
