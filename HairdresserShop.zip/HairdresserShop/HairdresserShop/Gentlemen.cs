﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    class Gentlemen: Client
    {
        private bool isTrimBeard;

        public bool IsTrimBeard { get => isTrimBeard; set => isTrimBeard = value; }

        public Gentlemen() { }

        public Gentlemen(int age, decimal height, string card, bool isTrimBeard) : base(age, height,card)
        {
            this.isTrimBeard = isTrimBeard;
        }
        public override void Operation()
        {
            Console.WriteLine("Appointment has been booked for the gentleman!");
        }
        public override string ToString()
        {
            return string.Format("This is Gentleman with age {0}, height {1} cm and credit card number {2}.\nHe has opted {3}", Age, Height, GetConcealedCard ,(IsTrimBeard) ? " trimming beard and moustaches in the additional service." : "only common services. ");
        }
    }
}
