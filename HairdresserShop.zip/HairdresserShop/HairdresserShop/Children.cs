﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    class Children: Client
    {
        private bool isSensitiveTrimmer;
        private bool isSeatAdjustable;

        public bool IsSensitiveTrimmer { get => isSensitiveTrimmer; set => isSensitiveTrimmer = value; }
        public bool IsSeatAdjustable { get => isSeatAdjustable; set => isSeatAdjustable = value; }
        public Children() { }

        public Children(int age, decimal height, string card, bool isSensitiveTrimmer,bool isSeatAdjustable) : base(age, height, card)
        {
            this.isSensitiveTrimmer = isSensitiveTrimmer;
            this.isSeatAdjustable = isSeatAdjustable;
        }
        public override void Operation()
        {
            Console.WriteLine("Child Appointment booked!");
        }
        public override string ToString()
        {
            return string.Format("This is a Child with age {0} ,height {1} cm and credit card number {2}.\nChild has opted {3} with {4}", Age, Height, GetConcealedCard, (IsSensitiveTrimmer)? "sensitive trim":" common services",(IsSeatAdjustable) ? " adjustable seat" : "normal seat ");
        }
    }
}
