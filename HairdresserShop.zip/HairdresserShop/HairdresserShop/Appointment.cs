﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    class Appointment
    {
        private string time;
        private Client customer;

        public string Time { get => time; set => time = value; }
        internal Client Customer { get => customer; set => customer = value; }
    }
}
