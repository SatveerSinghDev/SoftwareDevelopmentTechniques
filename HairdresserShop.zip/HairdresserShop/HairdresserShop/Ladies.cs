﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    class Ladies: Client
    {
        private bool isOccasion;

        public bool IsOccasion { get => isOccasion; set => isOccasion = value; }

        public Ladies() { }

        public Ladies(int age, decimal height, string card, bool isOccasion) : base(age, height, card)
        {
            this.isOccasion = isOccasion;
        }
        public override void Operation()
        {
            Console.WriteLine("Appointment has been booked for the lady!");
        }

        public override string ToString()
        {
            return string.Format("This is a Lady with age {0}, height {1} cm and credit card number {2}.\nShe has opted {3}", Age, Height, GetConcealedCard, (IsOccasion) ? " hair styling for occasion in the additional service." : "only common services. ");
        }
    }
}
