﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    class Program
    {
        enum AppointmentSlots
        {
            AM9h = 0,
            AM9h45m = 1,
            AM10h30m = 2,
            AM11h15m = 3,
            PM12h = 4,
            PM12h45m = 5,
            PM1h30m = 6,
            PM2h15m = 7,
            PM3h = 8,
            PM3h45m = 9,
            PM4h30m = 10
        }
        enum Clients
        {
            Gentlemen,
            Ladies,
            Children
        }
        enum Services
        {
            Hairwash,
            Hairdye,
            Hairtrim 

        }
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Go();
            Console.ReadKey();
        }

        public void Go()
        {
            var appointmentSlotTypes = Enum.GetNames(typeof(AppointmentSlots));
            var appointmentSlotValues = Enum.GetValues(typeof(AppointmentSlots));

            Hashtable appointmentTable = new Hashtable();
            Appointment[] appointment = new Appointment[appointmentSlotTypes.Length];
            
            for (int i = 0; i < appointmentSlotTypes.Length; i++)
            {
                string timings = (string)appointmentSlotTypes[i];

                int serialNumber = (int)appointmentSlotValues.GetValue(i);
               

                string format = timings.Substring(0, 2);
              
                string min = timings.Substring(2).Replace('m', ' ');
                if (min.IndexOf('h') == min.Length - 1)
                {
                    min = min.Replace('h', ':') + "00 ";
                }
                else
                {
                    min = min.Replace('h', ':');
                }
                min += format;
                
                appointmentTable.Add(serialNumber,min);
                appointment[i] = new Appointment();
                appointment[i].Time = min;

            }

            bool needAppointment = false;
            do
            {

                string response = string.Empty;
                do
                {
                   Console.Write("\nDo you need an appointment (y/n)?");
                    response = Console.ReadLine();
                } while((response != "Y") && (response != "y") && (response != "N") && (response != "n"));

                    if (response.Equals("n") || response.Equals("N"))
                    {
                        needAppointment = false;
                        continue;
                    }
                    needAppointment = true;
                Console.WriteLine("\n******Slots Available******\n");
               

                foreach(int val in appointmentSlotValues)
                {
                    if(appointmentTable.ContainsKey(val))
                    {
                        Console.WriteLine("{0}. {1}", (int)val+1, appointmentTable[val]);
                    }
                }
                
                string selectedSlot = string.Empty;
                int slot = 0;
                do
                {
                    Console.Write("Please select any slot [press 0 to exit]: ");
                    selectedSlot = Console.ReadLine();
                } while (!int.TryParse(selectedSlot, out slot) || (slot < 0 || slot > appointmentTable.Keys.Count));

                if (slot == 0)
                {
                    needAppointment = false;
                    continue;
                }
                else if(slot>0 && slot <= appointmentTable.Keys.Count)
                {
                    Console.WriteLine("\nWe offer common services for all ages and genders:");
                    var services = Enum.GetValues(typeof(Services));

                    foreach (var service in services)
                    {
                        Console.WriteLine("* {0}", service);
                    }

                    Console.WriteLine("\nAdditional offers for clients:");
                    var categoryclient = Enum.GetNames(typeof(Clients));
                    int i = 0;
                    foreach (var clients in categoryclient)
                    {
                        
                        Console.WriteLine("{0}. {1}",++i, clients);
                    }
                    string clientChoice = string.Empty;
                    int ch = 0;
                    do
                    {
                        Console.Write("Please enter your category(1-3) [press 0 to exit from here]: ");
                        clientChoice = Console.ReadLine();
                    } while (!int.TryParse(clientChoice,out ch) || (ch<0 || ch > categoryclient.Length) );

                    if (ch > 0)
                    {
                        

                        string clientAgeString = string.Empty;
                        int clientAge = 0;
                        int minAge = 0, maxAge = 0;
                        if ((ch - 1) == (int)Clients.Gentlemen || (ch - 1) == (int)Clients.Ladies)
                        {
                            minAge = 17;
                            maxAge = 70;
                            do
                            {
                                Console.Write("Client Age (17-70 yrs): ");
                                clientAgeString = Console.ReadLine();
                            } while (!int.TryParse(clientAgeString, out clientAge) || (clientAge < minAge || clientAge > maxAge));
                        }
                        else
                        {
                            minAge=4;
                            maxAge=16;
                                do
                            {
                                Console.Write("Client Age (4-16 yrs): ");
                                clientAgeString = Console.ReadLine();
                            } while (!int.TryParse(clientAgeString, out clientAge) || (clientAge < minAge || clientAge > maxAge));

                        }
                        

                        string clientHeightString = string.Empty;
                        decimal clientHeight = 0m;
                        do
                        {
                            Console.Write("Client Height ( 40-300 cms): ");
                            clientHeightString = Console.ReadLine();
                        } while (!decimal.TryParse(clientHeightString, out clientHeight) || (clientHeight < 40 || clientHeight > 300));

                        string clientCard = string.Empty;

                        do
                        {
                            Console.Write("Please Enter the credit card number (16 digit): ");
                            clientCard = Console.ReadLine();
                        } while (!(clientCard.All(char.IsDigit)) || !((clientCard.Length) == 16));
                        
                        Client customer = null;
                        
                        switch (ch - 1)
                        {
                            case (int)Clients.Gentlemen:
                                do
                                {
                                    Console.Write("Do you want trim beard and moustaches service?(Y/N) ");
                                    response = Console.ReadLine();
                                } while ( (response != "Y") && (response != "N") );
                                customer = new Gentlemen(clientAge, clientHeight,clientCard, (response == "Y") ? true : false);
                                break;
                            case (int)Clients.Ladies:
                                do
                                {
                                    Console.Write("Do you want hair styling service?(Y/N) ");
                                    response = Console.ReadLine();
                                } while ( (response != "Y") && (response != "N") );
                                customer = new Ladies(clientAge, clientHeight, clientCard, (response == "Y") ? true : false);
                                break;
                            case (int)Clients.Children:
                                string childResponse1 = string.Empty;
                                string childResponse2 = string.Empty;
                                do
                                {
                                    Console.Write("Do you want sensitive trimmer service?(Y/N) ");
                                    childResponse1 = Console.ReadLine();
                                } while ( (childResponse1 != "Y") && (childResponse1 != "N") );
                                do
                                {
                                    Console.Write("Do you want adjustable seat?(Y/N) ");
                                    childResponse2 = Console.ReadLine();
                                } while ((childResponse2 != "Y") && (childResponse2 != "N") );
                                customer = new Children(clientAge, clientHeight, clientCard, (childResponse1 == "Y") ? true : false, (childResponse2 == "Y") ? true : false);
                                break;
                               
                            default:
                                throw new Exception("You shouldn't be here");
                                
                        }
                        appointment[slot - 1].Customer = customer;
                        customer.Operation();
                        needAppointment = true;
                        appointmentTable.Remove(slot - 1);
                    }
                    
                    
                }
           
            } while (needAppointment && appointmentTable.Keys.Count > 0);

           


            for (int i = 0; i < appointment.Length; i++)
            {
                if (appointment[i].Customer != null)
                {
                    Console.WriteLine("\nTime: {0}, Customer: {1}",appointment[i].Time, appointment[i].Customer);
                }
            }

           

        }

    } 
}
