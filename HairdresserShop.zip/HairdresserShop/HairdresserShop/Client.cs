﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    class Client
    {
        private int age;
        private decimal height;
        private string card;

        public int Age { get => age; set => age = value; }
        public decimal Height { get => height; set => height = value; }
        public string Card { get => card; set => card = value; }
        
        public string GetConcealedCard { get => ConcealCard(); }
        public Client() { }
        public Client(int age,decimal height,string card)
        {
            this.age = age;
            this.height = height;
            this.card = card;
        }

        private string ConcealCard()
        {
            char[] cardArray = Card.ToCharArray();
            for (int i = 4; i < 12; i++)
            {
                cardArray[i] = 'X';
            }
            return new string(cardArray);
        }

        

        public virtual void Operation()
        {
            Console.WriteLine("Client is being called");
        }
    }
}
