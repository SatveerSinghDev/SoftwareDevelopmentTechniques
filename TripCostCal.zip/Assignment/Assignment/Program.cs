﻿/*
 * Course Name= SOFTWARE DEVELOPMENT TECHNIQUES PROG8145 SEC-1
 * Assignmnet-1
 * Question-1
 * Name- Satveer Singh
 * Student Id- 8738749
 */

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    public enum Transportation
    {
        Plane = 200,
        Train = 80,
        AutoBus = 50
    }
    class Program
    {
        static void Main(string[] args)
        {
            Program trip = new Program();
            trip.Travel();
            Console.ReadLine();
        }
        public void Travel()
        {

            int totalSpent = 0;
            int totalTrips = 0;
            int bus = 0, plane = 0, train = 0, busTrip = 0, planeTrip = 0, trainTrip = 0;
            int spent = 0;
            Console.OutputEncoding = Encoding.UTF8;
            CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("it-IT");
            Console.WriteLine("Angelo's trips");
            var transportName = Enum.GetNames(typeof(Transportation));
            foreach (string tName in transportName)
            {
                int numOfTrips = 0;
                string tripInput = string.Empty;
                int price = (int)Enum.Parse(typeof(Transportation), tName);
                do
                {
                    Console.Write("How many Trips in {0}? ", tName);
                    tripInput = Console.ReadLine();
                } while (!int.TryParse(tripInput, out numOfTrips) || numOfTrips < 0);

                if (numOfTrips > 0)
                {
                    spent = price * numOfTrips;
                    totalSpent += spent;
                    totalTrips += numOfTrips;
                }
                if (tName == "AutoBus")
                {
                    bus = spent;
                    busTrip = numOfTrips;
                }
                else if (tName == "Plane")
                {
                    plane = spent;
                    planeTrip = numOfTrips;
                }
                else
                {
                    train = spent;
                    trainTrip = numOfTrips;
                }
            }
            Console.WriteLine();
            Console.WriteLine("    Menu of Angelo's trips");
            Console.WriteLine();
            Console.WriteLine("1. Summary of Train trips");
            Console.WriteLine("2. Summary of Plane trips");
            Console.WriteLine("3. Summary of Autobus trips");
            Console.WriteLine("4. Summary of Angelo Trips");
            Console.WriteLine("5. Exit");
            int input = 0;
            string stringInput=string.Empty;
            bool status = true;
            do
            {

                Console.WriteLine();
                do
                {
                    Console.Write("Enter value between (1-4) or 5 for exit ");
                    stringInput = Console.ReadLine();
                } while (!int.TryParse(stringInput, out input) || input < 0);
                Console.WriteLine();
                switch (input)
                {

                    case 1:
                        int trainPrice = (int)Transportation.Train;
                        Console.WriteLine("     Summary of Train trips");
                        Console.WriteLine();
                        Console.WriteLine("Roundtrip price of Train ticket= {0}:- ", trainPrice.ToString("c"));
                        Console.WriteLine("Total Trips in Train= {0} ", trainTrip);
                        Console.WriteLine("Total price spent on Train tickets= {0}", train.ToString("c"));
                        status = true;
                        break;
                    case 2:
                        int planePrice = (int)Transportation.Plane;
                        Console.WriteLine("     Summary of Plane trips");
                        Console.WriteLine();
                        Console.WriteLine("Roundtrip price of Plane ticket= {0}:- ", planePrice.ToString("c"));
                        Console.WriteLine("Total Trips in Plane= {0} ", planeTrip);
                        Console.WriteLine("Total price spent on Plane tickets= {0}", plane.ToString("c"));
                        status = true;
                        break;

                    case 3:
                        int busPrice = (int)Transportation.AutoBus;
                        Console.WriteLine("     Summary of AutoBus trips");
                        Console.WriteLine();
                        Console.WriteLine("Roundtrip price of AutoBus ticket= {0}:- ", busPrice.ToString("c"));
                        Console.WriteLine("Total Trips in AutoBus= {0} ", busTrip);
                        Console.WriteLine("Total price spent on Autobus tickets= {0}", bus.ToString("c"));
                        status = true;
                        break;
                    case 4:
                        decimal avg = (decimal)totalSpent / totalTrips;
                        Console.WriteLine("     Summary of Angelo's Trips");
                        Console.WriteLine();
                        Console.WriteLine("Total trips of Angelo= {0}", totalTrips);
                        Console.WriteLine("Total spent on trips= {0}", totalSpent.ToString("c"));
                        Console.WriteLine("The average price of all trips= {0}", avg.ToString("c"));
                        status = true;
                        break;
                    case 5:
                        Console.WriteLine("Thank You!!!");
                        Console.WriteLine("Press enter to exit");
                        status = false;
                        break;
                    default:
                        Console.WriteLine("Wrong Input");
                        Console.WriteLine("Enter again!!");
                        status = true;
                        break;
                }

            } while (status);

        }
    }
}
