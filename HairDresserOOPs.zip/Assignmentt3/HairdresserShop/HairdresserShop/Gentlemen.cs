﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    class Gentlemen: Client
    {
        private bool isTrimBeard;

        public bool IsTrimBeard { get => isTrimBeard; set => isTrimBeard = value; }

        public Gentlemen() { }

        public Gentlemen(int age, decimal height, string card, bool isTrimBeard) : base(age, height,card)
        {
            this.isTrimBeard = isTrimBeard;
        }
        public override void Operation()
        {
            Console.WriteLine("Appointment has been booked for the gentleman!");
        }
       
        public override string ToString()
        {
            return string.Format("Gentleman\n Age: {0} years\n Height: {1}cm\n Credit Card Number: {2}\n He has opted {3}", Age, Height, GetConcealedCard, (IsTrimBeard) ? " trimming beard and moustaches in the additional service." : "only common services. ");
        }
    }
}
