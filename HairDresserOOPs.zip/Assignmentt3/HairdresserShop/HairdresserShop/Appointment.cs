﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    class Appointment : IAppointment //implemneted interface
    {
        private string time;
        private Client customer;
        
        public string Time { get => time; set => time = value; }
        public Client Customer { get => customer; set => customer = value; }

        public int CompareTo(IAppointment other)    //Comparing according to age
        {
            return Customer.Age.CompareTo(other.Customer.Age);
        }
        
    }
}
