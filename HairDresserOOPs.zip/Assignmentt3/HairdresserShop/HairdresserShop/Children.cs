﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairdresserShop
{
    class Children: Client
    {
        private bool isSensitiveTrimmer;
        private bool isSeatAdjustable;

        public bool IsSensitiveTrimmer { get => isSensitiveTrimmer; set => isSensitiveTrimmer = value; }
        public bool IsSeatAdjustable { get => isSeatAdjustable; set => isSeatAdjustable = value; }
        public Children() { }

        public Children(int age, decimal height, string card, bool isSensitiveTrimmer,bool isSeatAdjustable) : base(age, height, card)
        {
            this.isSensitiveTrimmer = isSensitiveTrimmer;
            this.isSeatAdjustable = isSeatAdjustable;
        }
        public override void Operation()
        {
            Console.WriteLine("Child Appointment booked!");
        }
        public override string ToString()
        {
            return string.Format("Child\n Age: {0} years\n Height: {1}cm\n Credit Card Number: {2}" +
                "\n Child has opted {3} with {4}", Age, Height, GetConcealedCard, 
                (IsSensitiveTrimmer)? "sensitive trim":" common services",(IsSeatAdjustable) ? " adjustable seat" : "normal seat ");
        }
    }
}
